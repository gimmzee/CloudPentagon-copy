import base64
import gzip
import json

def lambda_handler(event, context):
    output = []
    
    for record in event['records']:
        record_id = record['recordId']
        
        try:
            payload = base64.b64decode(record['data'])
            
            try:
                payload = gzip.decompress(payload)
            except:
                pass
            
            log_data = json.loads(payload)
            
            # Control message 무시
            if log_data.get('messageType') == 'CONTROL_MESSAGE':
                output.append({
                    'recordId': record_id,
                    'result': 'Dropped',
                    'data': record['data']
                })
                continue
            
            if 'logEvents' in log_data and log_data['logEvents']:
                # 첫 번째 이벤트만 사용하거나, 배치로 묶음
                first_event = log_data['logEvents'][0]
                
                document = {
                    '@timestamp': first_event.get('timestamp'),
                    'timestamp': first_event.get('timestamp'),
                    'message': first_event.get('message', ''),
                    'logGroup': log_data.get('logGroup', ''),
                    'logStream': log_data.get('logStream', ''),
                    'owner': log_data.get('owner', ''),
                    'messageType': log_data.get('messageType', ''),
                    'eventCount': len(log_data['logEvents'])
                }
                
                # 여러 이벤트가 있으면 messages 배열에 저장
                if len(log_data['logEvents']) > 1:
                    document['allMessages'] = [e.get('message', '') for e in log_data['logEvents']]
                
                try:
                    msg = json.loads(first_event.get('message', ''))
                    if isinstance(msg, dict):
                        document['parsed'] = msg
                except:
                    pass
                
                # 핵심: 단일 JSON 문서 + newline (Firehose OpenSearch 요구사항)
                result_data = json.dumps(document) + '\n'
                
                output.append({
                    'recordId': record_id,
                    'result': 'Ok',
                    'data': base64.b64encode(result_data.encode('utf-8')).decode('utf-8')
                })
            else:
                output.append({
                    'recordId': record_id,
                    'result': 'Dropped',
                    'data': record['data']
                })
                
        except Exception as e:
            output.append({
                'recordId': record_id,
                'result': 'ProcessingFailed',
                'data': record['data']
            })
    
    return {'records': output}
