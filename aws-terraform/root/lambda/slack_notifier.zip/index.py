import json
import os
import urllib.request
import urllib.error
from datetime import datetime

def lambda_handler(event, context):
    webhook_url = os.environ.get('SLACK_WEBHOOK_URL', '')
    
    if not webhook_url:
        print("SLACK_WEBHOOK_URL is not set")
        return {'statusCode': 400, 'body': 'Webhook URL not configured'}
    
    for record in event.get('Records', []):
        try:
            # SNS 메시지 파싱
            sns_message = json.loads(record['Sns']['Message'])
            
            # 알람 정보 추출
            alarm_name = sns_message.get('AlarmName', 'Unknown Alarm')
            new_state = sns_message.get('NewStateValue', 'Unknown')
            old_state = sns_message.get('OldStateValue', 'Unknown')
            reason = sns_message.get('NewStateReason', 'No reason provided')
            timestamp = sns_message.get('StateChangeTime', datetime.now().isoformat())
            region = sns_message.get('Region', 'Unknown')
            
            # 상태에 따른 색상 및 이모지 설정
            if new_state == 'ALARM':
                color = '#FF0000'  # 빨간색
                emoji = '🚨'
                status_text = 'ALARM 발생'
            elif new_state == 'OK':
                color = '#00FF00'  # 초록색
                emoji = '✅'
                status_text = '정상 복구'
            else:
                color = '#FFFF00'  # 노란색
                emoji = '⚠️'
                status_text = 'INSUFFICIENT_DATA'
            
            # Slack 메시지 구성
            slack_message = {
                "attachments": [
                    {
                        "color": color,
                        "title": f"{emoji} [{status_text}] {alarm_name}",
                        "fields": [
                            {
                                "title": "상태 변경",
                                "value": f"{old_state} → {new_state}",
                                "short": True
                            },
                            {
                                "title": "리전",
                                "value": region,
                                "short": True
                            },
                            {
                                "title": "발생 시간",
                                "value": timestamp,
                                "short": True
                            },
                            {
                                "title": "원인",
                                "value": reason[:500] if len(reason) > 500 else reason,
                                "short": False
                            }
                        ],
                        "footer": "CloudPentagon Monitoring System",
                        "footer_icon": "https://a.slack-edge.com/80588/img/services/amazon_cloudwatch_512.png"
                    }
                ]
            }
            
            # Slack으로 전송
            req = urllib.request.Request(
                webhook_url,
                data=json.dumps(slack_message).encode('utf-8'),
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            
            with urllib.request.urlopen(req, timeout=10) as response:
                print(f"Slack notification sent successfully: {response.status}")
                
        except urllib.error.URLError as e:
            print(f"Failed to send Slack notification: {e}")
            raise e
        except Exception as e:
            print(f"Error processing record: {e}")
            raise e
    
    return {'statusCode': 200, 'body': 'Notifications sent'}
